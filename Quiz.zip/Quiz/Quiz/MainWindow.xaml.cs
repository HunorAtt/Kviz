﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Quiz
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int kerdesszam = 0;
        int pont = 0;
        int jovalasz;
        public MainWindow()
        {
            InitializeComponent();
            temakorcb.Visibility = Visibility.Hidden;
            temakorlabel.Visibility = Visibility.Hidden;
            tesztinditasgomb.Visibility = Visibility.Hidden;
            kerdeslabel.Visibility = Visibility.Hidden;
            elsovalasz.Visibility = Visibility.Hidden;
            masodikvalasz.Visibility = Visibility.Hidden;
            harmadikvalasz.Visibility = Visibility.Hidden;
            negyedikvalasz.Visibility = Visibility.Hidden;
            elozo.Visibility = Visibility.Hidden;
            kiertekeles.Visibility = Visibility.Hidden;
            kovetkezo.Visibility = Visibility.Hidden;
        }

        private void tantargycb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (tantargycb.SelectedIndex == 0)
            {
                temakorlabel.Visibility = Visibility.Visible;
                temakorcb.Visibility = Visibility.Visible;
                tesztinditasgomb.Visibility = Visibility.Hidden;
                temakorcb.Items.Clear();
                temakorcb.Items.Add("Összeadás");
                temakorcb.Items.Add("Kivonás");
            }
            else if (tantargycb.SelectedIndex == 1)
            {
                temakorlabel.Visibility = Visibility.Visible;
                temakorcb.Visibility = Visibility.Visible;
                tesztinditasgomb.Visibility = Visibility.Hidden;
                temakorcb.Items.Clear();
                temakorcb.Items.Add("Szorzás");
                temakorcb.Items.Add("Osztás");
            }
        }

        private void temakorcb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (temakorcb.SelectedIndex == 0)
            {
                tesztinditasgomb.Visibility = Visibility.Visible;
            }
            else if (temakorcb.SelectedIndex == 1)
            {
                tesztinditasgomb.Visibility = Visibility.Visible;
            }
        }

        private void tesztinditasgomb_Click(object sender, RoutedEventArgs e)
        {
            kerdeslabel.Visibility = Visibility.Visible;
            elsovalasz.Visibility = Visibility.Visible;
            masodikvalasz.Visibility = Visibility.Visible;
            harmadikvalasz.Visibility = Visibility.Visible;
            negyedikvalasz.Visibility = Visibility.Visible;
            elozo.Visibility = Visibility.Visible;
            kiertekeles.Visibility = Visibility.Visible;
            kovetkezo.Visibility = Visibility.Visible;
            szovegfrissites();
        }

        private void kovetkezo_Click(object sender, RoutedEventArgs e)
        {
            if (kerdesszam < 3)
            {
                kerdesszam++;
                szovegfrissites();
            }
        }

        private void elozo_Click(object sender, RoutedEventArgs e)
        {
            if (kerdesszam > 0)
            {
                kerdesszam--;
                szovegfrissites();
            }
        }

        private void szovegfrissites()
        {
            switch (tantargycb.SelectedIndex)
            {
                case 0:
                    switch (temakorcb.SelectedIndex)
                    {
                        case 0:
                            switch (kerdesszam)
                            {
                                case 0:
                                    kerdeslabel.Content = "1. Mennyi 1+1?";
                                    elsovalasz.Content = "1";
                                    masodikvalasz.Content = "2";
                                    harmadikvalasz.Content = "3";
                                    negyedikvalasz.Content = "4";
                                    jovalasz = 2;
                                    break;
                                case 1:
                                    kerdeslabel.Content = "2. Mennyi 2+2?";
                                    elsovalasz.Content = "2";
                                    masodikvalasz.Content = "1";
                                    harmadikvalasz.Content = "4";
                                    negyedikvalasz.Content = "3";
                                    jovalasz = 3;
                                    break;
                                case 2:
                                    kerdeslabel.Content = "3. Mennyi 3+3?";
                                    elsovalasz.Content = "8";
                                    masodikvalasz.Content = "6";
                                    harmadikvalasz.Content = "12";
                                    negyedikvalasz.Content = "10";
                                    jovalasz = 2;
                                    break;
                                case 3:
                                    kerdeslabel.Content = "4. Mennyi 4+4?";
                                    elsovalasz.Content = "6";
                                    masodikvalasz.Content = "8";
                                    harmadikvalasz.Content = "10";
                                    negyedikvalasz.Content = "12";
                                    jovalasz = 2;
                                    break;
                            }
                            break;
                        case 1:
                            switch (kerdesszam)
                            {
                                case 0:
                                    kerdeslabel.Content = "1. Mennyi 1-1?";
                                    elsovalasz.Content = "-1";
                                    masodikvalasz.Content = "0";
                                    harmadikvalasz.Content = "1";
                                    negyedikvalasz.Content = "2";
                                    jovalasz = 2;
                                    break;
                                case 1:
                                    kerdeslabel.Content = "2. Mennyi 2-1?";
                                    elsovalasz.Content = "0";
                                    masodikvalasz.Content = "-1";
                                    harmadikvalasz.Content = "2";
                                    negyedikvalasz.Content = "1";
                                    jovalasz = 4;
                                    break;
                                case 2:
                                    kerdeslabel.Content = "3. Mennyi 3-5?";
                                    elsovalasz.Content = "-4";
                                    masodikvalasz.Content = "-5";
                                    harmadikvalasz.Content = "-2";
                                    negyedikvalasz.Content = "-3";
                                    jovalasz = 3;
                                    break;
                                case 3:
                                    kerdeslabel.Content = "4. Mennyi 5-10?";
                                    elsovalasz.Content = "-5";
                                    masodikvalasz.Content = "-4";
                                    harmadikvalasz.Content = "-3";
                                    negyedikvalasz.Content = "-2";
                                    jovalasz = 1;
                                    break;
                            }
                            break;
                    }
                    break;
                case 1:
                    switch (temakorcb.SelectedIndex)
                    {
                        case 0:
                            switch (kerdesszam)
                            {
                                case 0:
                                    kerdeslabel.Content = "1. Mennyi 1*1?";
                                    elsovalasz.Content = "1";
                                    masodikvalasz.Content = "2";
                                    harmadikvalasz.Content = "3";
                                    negyedikvalasz.Content = "4";
                                    jovalasz = 1;
                                    break;
                                case 1:
                                    kerdeslabel.Content = "2. Mennyi 2*2?";
                                    elsovalasz.Content = "2";
                                    masodikvalasz.Content = "1";
                                    harmadikvalasz.Content = "4";
                                    negyedikvalasz.Content = "3";
                                    jovalasz = 3;
                                    break;
                                case 2:
                                    kerdeslabel.Content = "3. Mennyi 2*5?";
                                    elsovalasz.Content = "10";
                                    masodikvalasz.Content = "20";
                                    harmadikvalasz.Content = "30";
                                    negyedikvalasz.Content = "40";
                                    jovalasz = 1;
                                    break;
                                case 3:
                                    kerdeslabel.Content = "4. Mennyi 4*5?";
                                    elsovalasz.Content = "20";
                                    masodikvalasz.Content = "10";
                                    harmadikvalasz.Content = "40";
                                    negyedikvalasz.Content = "30";
                                    jovalasz = 1;
                                    break;
                            }
                            break;
                        case 1:
                            switch (kerdesszam)
                            {
                                case 0:
                                    kerdeslabel.Content = "1. Mennyi 1/1";
                                    elsovalasz.Content = "1";
                                    masodikvalasz.Content = "2";
                                    harmadikvalasz.Content = "3";
                                    negyedikvalasz.Content = "4";
                                    jovalasz = 1;
                                    break;
                                case 1:
                                    kerdeslabel.Content = "2. Mennyi 2/1?";
                                    elsovalasz.Content = "1";
                                    masodikvalasz.Content = "2";
                                    harmadikvalasz.Content = "3";
                                    negyedikvalasz.Content = "4";
                                    jovalasz = 2;
                                    break;
                                case 2:
                                    kerdeslabel.Content = "3. Mennyi 20/4?";
                                    elsovalasz.Content = "5";
                                    masodikvalasz.Content = "6";
                                    harmadikvalasz.Content = "7";
                                    negyedikvalasz.Content = "8";
                                    jovalasz = 1;
                                    break;
                                case 3:
                                    kerdeslabel.Content = "4. Mennyi 36/6?";
                                    elsovalasz.Content = "5";
                                    masodikvalasz.Content = "6";
                                    harmadikvalasz.Content = "7";
                                    negyedikvalasz.Content = "8";
                                    jovalasz = 2;
                                    break;
                            }
                            break;
                    }
                    break;
            }
        }

        private void kattintasra(object sender, RoutedEventArgs e)
        {
            var gomb = (Button)sender;
            int buttonTag = Convert.ToInt32(gomb.Tag);
            if (buttonTag == jovalasz)
            {
                pont++;
            }
            if (kerdesszam < 3)
            {
                kerdesszam++;
                szovegfrissites();
            }
            else if (kerdesszam == 3)
            {
                figyelmeztetes();
            }
        }

        private void figyelmeztetes()
        {
            MessageBox.Show("Elérted a quiz végét! A kiértékelés gombbal tudod megtekinteni eredményed.");
        }

        private void kiertekeles_Click(object sender, RoutedEventArgs e)
        {
            vege();
        }

        private void vege()
        {
            MessageBox.Show("Sikeresen elért pontok: " + pont);

            temakorcb.Visibility = Visibility.Hidden;
            temakorlabel.Visibility = Visibility.Hidden;
            tesztinditasgomb.Visibility = Visibility.Hidden;
            kerdeslabel.Visibility = Visibility.Hidden;
            elsovalasz.Visibility = Visibility.Hidden;
            masodikvalasz.Visibility = Visibility.Hidden;
            harmadikvalasz.Visibility = Visibility.Hidden;
            negyedikvalasz.Visibility = Visibility.Hidden;
            elozo.Visibility = Visibility.Hidden;
            kiertekeles.Visibility = Visibility.Hidden;
            kovetkezo.Visibility = Visibility.Hidden;

            pont = 0;
            kerdesszam = 0;
        }
    }
}
